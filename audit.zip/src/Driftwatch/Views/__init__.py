"""Presentation adapters for Driftwatch."""
